// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <string>       // std::string
#include <typeinfo>     // typeid

/// <summary>
/// Adds increment to start for the requested number of steps.
/// </summary>
/// <typeparam name="T">A standard numeric type</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <param name="result">Receives the completed result or the last safe value</param>
/// <returns>True when every addition succeeds; otherwise false</returns>
template <typename T>
bool add_numbers(T const& start, T const& increment,
    unsigned long int const& steps, T& result)
{
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check both limits before adding. Using lowest() is important because
        // min() is the smallest positive normalized value for floating types.
        if ((increment > T{ 0 } &&
            result > std::numeric_limits<T>::max() - increment) ||
            (increment < T{ 0 } &&
                result < std::numeric_limits<T>::lowest() - increment))
        {
            return false;
        }

        result += increment;
    }

    return true;
}

/// <summary>
/// Subtracts decrement from start for the requested number of steps.
/// </summary>
/// <typeparam name="T">A standard numeric type</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="decrement">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <param name="result">Receives the completed result or the last safe value</param>
/// <returns>True when every subtraction succeeds; otherwise false</returns>
template <typename T>
bool subtract_numbers(T const& start, T const& decrement,
    unsigned long int const& steps, T& result)
{
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Subtracting a positive value can cross the lower limit. Subtracting
        // a negative value can cross the upper limit, so check both directions.
        if ((decrement > T{ 0 } &&
            result < std::numeric_limits<T>::lowest() + decrement) ||
            (decrement < T{ 0 } &&
                result > std::numeric_limits<T>::max() + decrement))
        {
            return false;
        }

        result -= decrement;
    }

    return true;
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character.

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    T result{};
    bool success = add_numbers<T>(start, increment, steps, result);
    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", "
        << +increment << ", " << steps << ") = " << +result
        << " | Overflow: " << std::boolalpha << !success << std::endl;

    success = add_numbers<T>(start, increment, steps + 1, result);
    std::cout << "\tAdding Numbers With Overflow (" << +start << ", "
        << +increment << ", " << (steps + 1) << ") = " << +result
        << " | Overflow: " << std::boolalpha << !success << std::endl;
}

template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    T result{};
    bool success = subtract_numbers<T>(start, decrement, steps, result);
    std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", "
        << +decrement << ", " << steps << ") = " << +result
        << " | Underflow: " << std::boolalpha << !success << std::endl;

    // Starting at the actual lower limit makes this a genuine underflow test
    // for signed, unsigned, and floating-point types.
    const T underflow_start = std::numeric_limits<T>::lowest();
    success = subtract_numbers<T>(underflow_start, decrement, 1, result);
    std::cout << "\tSubtracting Numbers With Underflow (" << +underflow_start
        << ", " << +decrement << ", 1) = " << +result
        << " | Underflow: " << std::boolalpha << !success << std::endl;
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primitive types
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primitive types
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu