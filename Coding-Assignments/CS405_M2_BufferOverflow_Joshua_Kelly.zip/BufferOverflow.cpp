// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // Use a string for input so user data cannot exceed a fixed-size buffer.
  // Inputs longer than 20 characters are detected and reported to the user.
  const std::string account_number = "CharlieBrown42";
  std::string user_input;

  std::cout << "Enter a value: ";
  std::getline(std::cin, user_input);

  if (user_input.length() > 20)
  {
    std::cout << "Buffer overflow prevented: input exceeds 20 characters." << std::endl;
  }
  else
  {
    std::cout << "You entered: " << user_input << std::endl;
  }

  std::cout << "Account Number = " << account_number << std::endl;

  return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu