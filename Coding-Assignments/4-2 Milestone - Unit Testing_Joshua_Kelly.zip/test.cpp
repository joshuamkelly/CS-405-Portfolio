// Uncomment the next line to use precompiled headers
//#include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
#include <cassert>
#include <cstdlib>
#include <ctime>
#include <memory>
#include <stdexcept>
#include <vector>
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    //  initialize random seed
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
  // create a smart pointer to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { // create a new collection to be used in the test
    collection.reset( new std::vector<int>);
  }

  void TearDown() override
  { //  erase all elements in the collection, if any remain
    collection->clear();
    // free the pointer
    collection.reset(nullptr);
  }

  // helper function to add random values from 0 to 99 count times to the collection
  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that the collection smart pointer is valid.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::SetUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  // is the collection created
  ASSERT_TRUE(collection);

  // the owned pointer must not be null
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0u);
}

// Intentional failure demonstration; excluded from the final test run.
/*
TEST_F(CollectionTest, AlwaysFail)
{
  FAIL();
}
*/

// Predefined test 1: adding one entry changes an empty vector's size.
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(0u, collection->size());
  add_entries(1);
  EXPECT_FALSE(collection->empty());
  EXPECT_EQ(1u, collection->size());
}

// Predefined test 2: all five added entries are present.
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  ASSERT_TRUE(collection->empty());
  add_entries(5);
  EXPECT_EQ(5u, collection->size());
  EXPECT_FALSE(collection->empty());
}

// Predefined test 3: check each requested size independently.
TEST_F(CollectionTest, MaxSizeIsAtLeastSizeForZeroOneFiveAndTenEntries)
{
  for (const int count : {0, 1, 5, 10})
  {
    SCOPED_TRACE(count);
    collection->clear();
    // The helper requires a strictly positive count.
    if (count > 0)
      add_entries(count);
    ASSERT_EQ(static_cast<std::size_t>(count), collection->size());
    EXPECT_GE(collection->max_size(), collection->size());
  }
}

// Predefined test 4: allocated capacity must accommodate every element.
TEST_F(CollectionTest, CapacityIsAtLeastSizeForZeroOneFiveAndTenEntries)
{
  for (const int count : {0, 1, 5, 10})
  {
    SCOPED_TRACE(count);
    collection->clear();
    if (count > 0)
      add_entries(count);
    ASSERT_EQ(static_cast<std::size_t>(count), collection->size());
    EXPECT_GE(collection->capacity(), collection->size());
  }
}

// Predefined test 5: growing the vector changes its logical size.
TEST_F(CollectionTest, ResizeIncreasesSize)
{
  add_entries(5);
  ASSERT_EQ(5u, collection->size());
  collection->resize(10);
  EXPECT_EQ(10u, collection->size());
}

// Predefined test 6: shrinking the vector changes its logical size.
TEST_F(CollectionTest, ResizeDecreasesSize)
{
  add_entries(10);
  ASSERT_EQ(10u, collection->size());
  collection->resize(5);
  EXPECT_EQ(5u, collection->size());
}

// Predefined test 7: resizing to zero removes every element.
TEST_F(CollectionTest, ResizeToZeroEmptiesVector)
{
  add_entries(5);
  ASSERT_EQ(5u, collection->size());
  collection->resize(0);
  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(0u, collection->size());
}

// Predefined test 8: clear removes all elements from a nonempty vector.
TEST_F(CollectionTest, ClearRemovesAllElements)
{
  add_entries(5);
  ASSERT_EQ(5u, collection->size());
  collection->clear();
  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(0u, collection->size());
}

// Predefined test 9: erasing the full iterator range removes all elements.
TEST_F(CollectionTest, EraseEntireRangeEmptiesVector)
{
  add_entries(5);
  ASSERT_EQ(5u, collection->size());
  collection->erase(collection->begin(), collection->end());
  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(0u, collection->size());
}

// Predefined test 10: reserve changes storage capacity, not element count.
TEST_F(CollectionTest, ReserveIncreasesCapacityWithoutChangingSize)
{
  add_entries(5);
  ASSERT_EQ(5u, collection->size());
  const auto oldSize = collection->size();
  const auto oldCapacity = collection->capacity();
  const auto requestedCapacity = oldCapacity + 10;
  collection->reserve(requestedCapacity);
  // Implementations may allocate more than the requested capacity.
  EXPECT_GE(collection->capacity(), requestedCapacity);
  EXPECT_GT(collection->capacity(), oldCapacity);
  EXPECT_EQ(oldSize, collection->size());
}

// Predefined test 11 (negative): size() is one past the last valid index.
TEST_F(CollectionTest, AtThrowsWhenIndexEqualsSize)
{
  add_entries(5);
  ASSERT_EQ(5u, collection->size());
  EXPECT_THROW(static_cast<void>(collection->at(collection->size())), std::out_of_range);
}

// Custom positive test: removing the last element preserves earlier values.
TEST_F(CollectionTest, PopBackRemovesLastElementAndPreservesEarlierElements)
{
  collection->push_back(10);
  collection->push_back(20);
  collection->push_back(30);
  ASSERT_EQ(3u, collection->size());
  collection->pop_back();
  ASSERT_EQ(2u, collection->size());
  EXPECT_EQ(10, collection->at(0));
  EXPECT_EQ(20, collection->at(1));
}

// Custom negative test: a previously valid index becomes invalid after shrinking.
TEST_F(CollectionTest, AtThrowsForIndexInvalidatedByResize)
{
  add_entries(5);
  ASSERT_EQ(5u, collection->size());
  ASSERT_NO_THROW(static_cast<void>(collection->at(4)));
  collection->resize(2);
  ASSERT_EQ(2u, collection->size());
  EXPECT_THROW(static_cast<void>(collection->at(4)), std::out_of_range);
}
