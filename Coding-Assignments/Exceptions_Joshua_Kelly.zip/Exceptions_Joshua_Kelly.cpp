// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>
#include <stdexcept>

// Identify application-specific failures separately from standard exceptions.
class CustomApplicationException : public std::exception
{
public:
  const char* what() const noexcept override
  {
    return "Custom application logic failed.";
  }
};

bool do_even_more_custom_application_logic()
{
  // Demonstrate a standard exception handled by the calling function.
  throw std::runtime_error("Even more custom application logic failed.");

  std::cout << "Running Even More Custom Application Logic." << std::endl;

  return true;
}
void do_custom_application_logic()
{
  std::cout << "Running Custom Application Logic." << std::endl;

  // Report the failure locally so processing can continue to the custom exception.
  try
  {
    if(do_even_more_custom_application_logic())
    {
      std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
  }
  catch (const std::exception& ex)
  {
    std::cout << "Application logic error: " << ex.what() << std::endl;
  }

  // Let main handle this application-specific exception.
  throw CustomApplicationException{};

  std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
  // Floating-point division by zero does not automatically throw a C++ exception.
  if (den == 0.0f)
  {
    throw std::invalid_argument("Division by zero is not allowed.");
  }
  return (num / den);
}

void do_division() noexcept
{
  float numerator = 10.0f;
  float denominator = 0;

  // Handle divide's expected exception before it can escape this noexcept function.
  try
  {
    auto result = divide(numerator, denominator);
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  catch (const std::invalid_argument& ex)
  {
    std::cout << "Division error: " << ex.what() << std::endl;
  }
}

int main()
{
  try
  {
    std::cout << "Exceptions Tests!" << std::endl;

    do_division();
    do_custom_application_logic();
  }
  // Catch the derived type before its std::exception base class.
  catch (const CustomApplicationException& ex)
  {
    std::cout << "Custom application error: " << ex.what() << std::endl;
  }
  catch (const std::exception& ex)
  {
    std::cout << "Standard exception: " << ex.what() << std::endl;
  }
  catch (...)
  {
    // A catch-all provides no typed exception object for calling what().
    std::cout << "Unknown exception: no exception message is available." << std::endl;
  }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
